

create_reader();



sub create_reader
{
	
	my $ver = 0;
	if (-d ".svn")
	{
		open SVN, ".svn/entries";
		my $xxx = <SVN>;
		$xxx = <SVN>;
		$xxx = <SVN>;
		$xxx = <SVN>;
		chomp $xxx;
		$ver = $xxx;
		close SVN;
	}
	
	print <<"CODE";
function READ_HOTSTART_VARS
	use common_module
	implicit none
	integer M,N,Vtype,Vdims,Dsize1,Dsize2,ver,En
	integer READ_HOTSTART_VARS
	
	! Should be $ver
	read(77) ver
	
	! No error
	READ_HOTSTART_VARS = 0

	!if (ver .ne. CURRENT_REVISION) then
	!	! Error
	!	READ_HOTSTART_VARS = 1
	!	return
	!endif
	
CODE
	;
	
	while (<>)
	{
	  chomp;
	  next if (m/\!\@ITM\@IGNORE/);
	  if (m/^\s*(double\s*precision|integer),\s+ALLOCATABLE\s+::\s+(.*)$/i)
	  {
	  	my $type = $1;
	  	my $rest = $2;
	  	$rest =~ s/\s*\!.*$//;
	  	$rest =~ s/^\s*(.*?)\s*$/$1/;
	  	
	  	(my $dims = $rest) =~ s/^.*\((.*?)\)$/$1/;
	  	(my $name = $rest) =~ s/\(.*$//;
	  	$dims =~ s/[^:]//g;

	  	if (length $dims == 1)
	  	{
	  		print <<"CODE";
	!$name
	read(77) En
	if (En == 1) then ! check if enabled
		read(77) Vtype
		if (Vtype == 1) then
			read(77) Vdims,Dsize1
			if (Vdims == 1) then
				allocate ($name(Dsize1))
				read(77) ($name(M),M=1,Dsize1)
			else
				READ_HOTSTART_VARS = 1
				return
			endif
		else
			READ_HOTSTART_VARS = 1
			return
		endif
	endif
CODE
				;
	  	}
	  	elsif (length $dims == 2)
	  	{
	  		print <<"CODE";
	!$name
	read(77) En
	if (En == 1) then ! check if enabled
		read(77) Vtype
		if (Vtype == 1) then
			read(77) Vdims,Dsize1
			if (Vdims == 2) then
				read(77) Dsize2
				allocate ($name(Dsize1,Dsize2))
				read(77) (($name(N,M),N=1,Dsize1),M=1,Dsize2)
			else
				READ_HOTSTART_VARS = 1
				return
			endif
		else
			READ_HOTSTART_VARS = 1
			return
		endif
	endif
CODE
				;
	  	}
	  	else
	  	{
	  		print STDERR "undetected number of dimensions: '$_'\n";
	  	}
	  }
	  elsif (m/^\s*[cC\!]/ or m/^\s*$/)
	  {
	  	print "!$_\n";
	  }
	  elsif (m/^\s*(double\s*precision|integer)\s+(.*)$/i)
	  {
	  	my $type = $1;
	  	my $rest = $2;
	  	$rest =~ s/\s*\!.*$//;
	  	$rest =~ s/^\s*(.*?)\s*$/$1/;
	  	
	  	if ($rest =~ m/[\(\)]/)
	  	{
	  		(my $name = $rest) =~ s/\(.*$//;
	  		(my $count = $rest) =~ s/^.*\((\d+)\)$/$1/;
	  		print <<"CODE";
	!$name
	read(77) Vtype
	if (Vtype == 3) then
		read(77) Vdims,Dsize1
		if (Vdims == 1) then
			!static array, no need to allocate
			read(77) ($name(M),M=1,Dsize1)
		else
			READ_HOTSTART_VARS = 1
			return
		endif
	else
		READ_HOTSTART_VARS = 1
		return
	endif
CODE
				;
	  	}
	  	else
	  	{
	  		print <<"CODE";
	!$rest
	read(77) Vtype
	if (Vtype == 2) then
		read(77) $rest
	else
		READ_HOTSTART_VARS = 1
		return
	endif
CODE
				;
	  	}
	  }
	  elsif (!m/implicit/ and !m/MODULE/ and !m/parameter/)
	  {
	  	print STDERR "unrecognized: '$_'\n";
	  }
	}
	
	print "end function\n";
	

}
