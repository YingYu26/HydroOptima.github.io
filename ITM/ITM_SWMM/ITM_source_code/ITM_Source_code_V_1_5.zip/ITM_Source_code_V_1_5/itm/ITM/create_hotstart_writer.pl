

create_writer();



sub create_writer
{
	
	my $ver = 0;
	if (-d ".svn")
	{
		open SVN, ".svn/entries";
		my $xxx = <SVN>;
		$xxx = <SVN>;
		$xxx = <SVN>;
		$xxx = <SVN>;
		chomp $xxx;
		$ver = $xxx;
		close SVN;
	}
	
	print <<"CODE";
function WRITE_HOTSTART_VARS
	use common_module
	implicit none
	integer M,N,temp
	integer WRITE_HOTSTART_VARS

	WRITE_HOTSTART_VARS = 0
	
	!if (${ver} .ne. CURRENT_REVISION) then
	!	WRITE_HOTSTART_VARS = 1
	!	write(99,*) 'CURRENT_REVISION does not match the WRITE_HOTSTART_VARS version of $ver'
	!	write(99,*) 'Check versions and recompile if necessary.'
	!	call endprog
	!endif
	
	write(77) ${ver}
	
CODE
	;
	
	while (<>)
	{
	  chomp;
	  next if (m/\!\@ITM\@IGNORE/);
	  if (m/^\s*(double\s*precision|integer),\s+ALLOCATABLE\s+::\s+(.*)$/i)
	  {
	  	my $type = $1;
	  	my $rest = $2;
	  	$rest =~ s/\s*\!.*$//;
	  	$rest =~ s/^\s*(.*?)\s*$/$1/;
	  	
	  	(my $dims = $rest) =~ s/^.*\((.*?)\)$/$1/;
	  	(my $name = $rest) =~ s/\(.*$//;
	  	$dims =~ s/[^:]//g;
	  	print <<"CODE";
	if (ALLOCATED($name)) then
CODE
			;
  		# 1st pos for enabled, second pos for type, third pos for # dimensions,
  		# fourth/fifth pos for dimensions
	  	if (length $dims == 1)
	  	{
	  		print <<"CODE";
		write(77) 1
		temp = UBOUND($name,1)
		write(77) 1,1,temp
		write(77) ($name(M),M=1,temp)
CODE
				;
	  	}
	  	elsif (length $dims == 2)
	  	{
	  		print <<"CODE";
		write(77) 1
		temp = UBOUND($name,1)
		write(77) 1,2,temp,UBOUND($name,2)
		write(77) (($name(N,M),N=1,temp),M=1,UBOUND($name,2))
CODE
				;
	  	}
	  	else
	  	{
	  		print STDERR "undetected number of dimensions: '$_'\n";
	  	}
	  	print <<"CODE";
	else
		write(77) 0
	endif
CODE
			;
	  }
	  elsif (m/^\s*[cC\!]/ or m/^\s*$/)
	  {
	  	print "!$_\n";
	  }
	  elsif (m/^\s*(double\s*precision|integer)\s+(.*)$/i)
	  {
	  	my $type = $1;
	  	my $rest = $2;
	  	$rest =~ s/\s*\!.*$//;
	  	$rest =~ s/^\s*(.*?)\s*$/$1/;
	  	
	  	if ($rest =~ m/[\(\)]/)
	  	{
	  		(my $name = $rest) =~ s/\(.*$//;
	  		(my $count = $rest) =~ s/^.*\((\d+)\)$/$1/;
	  		print "\twrite(77) 3,1,$count,($name(M),M=1,$count)\n";
	  	}
	  	else
	  	{
	  		print "\twrite(77) 2,$rest\n";
	  	}
	  }
	  elsif (!m/implicit/ and !m/MODULE/ and !m/parameter/)
	  {
	  	print STDERR "unrecognized: '$_'\n";
	  }
	}
	
	print "end function\n";
	

}
