

create_deallocater();



sub create_deallocater
{
	
	my $ver = 0;
	if (-d ".svn")
	{
		open SVN, ".svn/entries";
		my $xxx = <SVN>;
		$xxx = <SVN>;
		$xxx = <SVN>;
		$xxx = <SVN>;
		chomp $xxx;
		$ver = $xxx;
		close SVN;
	}
	
	print <<"CODE";
	subroutine deallocateALL
	use common_module
	implicit none
	
	!if ($ver .ne. CURRENT_REVISION) then
	!	! Error
	!	write(99,*) 'CURRENT_REVISION does not match the deallocator ',
	!   &			'version of $ver'
	!	write(99,*) 'Check versions and recompile if necessary.'
	!	close(99)
	!	stop
	!endif
	
CODE
	;
	
	while (<>)
	{
	  chomp;
	  next if (m/\!\@ITM\@IGNORE/);
	  if (m/^\s*(double\s*precision|integer),\s+ALLOCATABLE\s+::\s+(.*)$/i)
	  {
	  	my $type = $1;
	  	my $rest = $2;
	  	$rest =~ s/\s*\!.*$//;
	  	$rest =~ s/^\s*(.*?)\s*$/$1/;
	  	
	  	(my $dims = $rest) =~ s/^.*\((.*?)\)$/$1/;
	  	(my $name = $rest) =~ s/\(.*$//;
	  	$dims =~ s/[^:]//g;
	  	print "\tif (ALLOCATED($name)) DEALLOCATE($name)\n";
	  }
	  elsif (m/^\s*[cC\!]/ or m/^\s*$/)
	  {
	  	print "!$_\n";
	  }
	}
	
	print "\tend subroutine\n";
	

}
