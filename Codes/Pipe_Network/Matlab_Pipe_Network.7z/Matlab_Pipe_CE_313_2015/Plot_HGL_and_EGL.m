% =========================================================================
% Function for calculating and plotting HGL and EGL of pipes in a system
% =========================================================================
% Date Created: 01/26/13
% Date Modified: 04/15/15

%Purpose: To calculate and plot the energy grade line of each pipe in a system
%with multiple pipes from the pressure head, flow and pipe characteristics.
%
% =========================================================================
function Plot_HGL_and_EGL(N,x,D,Length_plot,Z_node,CONDUIT_STRING_ID,Conduit_plot,Conduit_side_plot,Number_of_nodes_to_plot,Node_plot_string,g)
n=0; %counter for legend of the plot
%defining the legends of the plot which will be created in this function
%legendmatrix{1}=sprintf('Ground elevation'); %legend of the solid lines

%HHHHHHHH = Number_of_nodes_to_plot

for i=1:Number_of_nodes_to_plot-1;
    k = Conduit_plot(i);
    s1 = CONDUIT_STRING_ID{k};   
    
    legendmatrix{2*i-1}=sprintf('HGL-Pipe %s ',s1); %legend of the solid lines
    legendmatrix{2*i}=sprintf('EGL-Pipe %s ',s1);%legend of dash lines
    n=n+1; 
end

rrs = Number_of_nodes_to_plot-1;
legendmatrix{2*rrs+1}=sprintf('Elevation of Nodes');%legend of dash lines

 %legendmatrix{1}=sprintf('Ground elevation'); %legend of the solid lines

 
screen_size = get(0, 'ScreenSize');     %1/2)this function will maximize the plot window
set(figure, 'Position', [0 0 screen_size(3) screen_size(4) ] );   %2/2)this function will maximize the plot window

x1 = 1.05*Length_plot(1);
k = Conduit_plot(1);
if (Conduit_side_plot(1) == 1);
    y1 = x(k);
else 
    y1 = x(N+k);
end   
text(x1,y1,Node_plot_string(1), 'FontSize',40, 'color','k'); 

%text(x1,y1,[Node_plot_string(1),'\fontsize{16}black'])
%text(100.0,100.0,Node_plot_string(1))
hold on



for i = 1:Number_of_nodes_to_plot-1;
    %NodePlot1 = Node_plot(i); 
    k = Conduit_plot(i);
    
    colors = get(0,'defaultaxescolororder'); % for changing the color of the energy and hydraulic grade line for each pipe
    colors = colors(mod(0:N+3,length(colors))+1,:);
    
    if (Conduit_side_plot (2*i-1) == 1)
        plot([Length_plot(2*i-1);Length_plot(2*i)],[x(k);x(N+k)],'color',[colors(i+1,:)],'LineWidth',4);
    else 
        plot([Length_plot(2*i-1);Length_plot(2*i)],[x(N+k);x(k)],'color',[colors(i+1,:)],'LineWidth',4);
    end  
    
    x1 = Length_plot(2*i);
    k = Conduit_plot(i);
    if (Conduit_side_plot(2*i-1) == 1);
        y1 = x(N+k);
    else 
        y1 = x(k);
    end   
    text(x1,y1,Node_plot_string(i+1), 'FontSize',40, 'color','k'); 
    
    hold on;
    
    A(k) = (pi/4)*D(k)^2;  %Area of pipe    
    p = 2*N + k;  %x(p) is flow discharge in pipe "k"    
    v(k) = x(p)/A(k); %vel (k) is velocity in pipe "k"
    EL(k)=x(k)+(v(k))^2/(2*g); % calculating the energy grade line left 
    ER(k)=x(N+k)+(v(k))^2/(2*g);% calculating the energy grade line right
    
    
    if (Conduit_side_plot (2*i-1) == 1);
        plot([Length_plot(2*i-1);Length_plot(2*i)],[EL(k);ER(k)],'--','color',[colors(i+1,:)],'LineWidth',4);
    else 
        plot([Length_plot(2*i-1);Length_plot(2*i)],[ER(k);EL(k)],'--','color',[colors(i+1,:)],'LineWidth',4);
    end
    
    
end
hold on

%Ground elevation
plot(Length_plot, Z_node, '-', 'color', 'b', 'LineWidth',10);  


hold on;
    set(gca, 'XMinorGrid','on', 'YMinorGrid','on', 'XColor','k', 'YColor','k')
    title('Hydraulic Grade Line (solid line); Energy Grade Line (dash line)','FontSize',30, 'color','k' )
    set(gca,'FontSize',20);
    xlabel('Distance, meters')
    ylabel('Head, meters')
    h=legend(legendmatrix{1,:}); %dynamically allocated legend entries
    set(h,'FontSize',24,'Location','NorthEast', 'Box', 'on')

hold off

