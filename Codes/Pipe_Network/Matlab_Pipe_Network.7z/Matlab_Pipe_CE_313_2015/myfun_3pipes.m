% CE 313, Instructor: Arturo Leon, Ph.D., P.E.
% QUIZ 3
% This Matlab script can be used for solving flows and pressures in pipe distribution systems 
% Note that this script is in SI Units

function [ F ] = myfun_3pipes( x )
%Variables for a system with N PIPES (Use this convention)
% x1 = HL1 Left head in pipe 1
% x2 = HL2 Left head in pipe 2
%.     .....
% xN = HLN Left head in pipe N    

% xN+1 = HR_N+1 Right head in pipe 1
% xN+2 = HR_N+2 Right head in pipe 2 
%.  ......
% x2N = HL_2N Right head in pipe N

% x2N+1 = Q1 Flow in pipe 1
% x2N+2 = Q2 Flow in pipe 2
%.  	.....
% x3N = QN Flow in pipe N

%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%%Global variables being used in this function
% Number of pipes 
global N;
% Kinematic viscosity of fluid (m2/s)
global vis; 
% data of lengths (in meters)
global L;
% data of diameters (in meters)
global D;
% data of roughness (in milimiters)
global e;
% Minor losses at the interior of each pipe
global Kinternal;
% Minor losses at the left of each pipe (entrance conditions)    
global KL;   
% Minor losses at the right of each pipe (exit conditions)   myfun_3pipes.m
global KR;
global g %Gravity (SI)
global Number_nodes;
global Numb_pipes_at_a_node;
global ID_pipe_connected_to_a_Node;
global Nodetype;
global Reservoir_at_Node;
global Free_outflow_at_Node;
global Elevation_of_node;
global Water_Surface_elevation_Reservoir;
global Flow_at_Node;
global Flow_Value_External_Node;
global STOPCODE;   
%global hpump
global Pump_at_conduit
global A_pump
global B_pump
global C_pump

%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

%Check that a node connected to a single pipe has the adequate data
for j = 1:Number_nodes;
    if (Numb_pipes_at_a_node(j) == 1);        
        if (Reservoir_at_Node(j) + Free_outflow_at_Node(j) < 1); 
            fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
            fprintf('\n ERROR at Node %d\D',j);
            fprintf('\n This node has a single connecting pipe but according to the data is not a reservoir or');
            fprintf('\n an inflow. Please specify in the Excel data the type of boundary at this node');            
            fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&'); 
            STOPCODE = 1;
            break;            
        elseif (Reservoir_at_Node(j) + Free_outflow_at_Node (j) > 1); 
            fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
            fprintf('\n ERROR at Node %d\D',j);
            fprintf('\n This node has a single connecting pipe but according to the data is a reservoir AND');
            fprintf('\n an inflow. Please specify in the Excel data the correct boundary at this node');            
            fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');   
            STOPCODE = 1;
            break;
        end
    end
end



%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
for i = 1:N;    
    A(i) = (pi/4)*D(i)^2;  %Area of pipe
    eD(i) = e(i)/D(i)/1000;  %Relative roughness 
    p = 2*N + i;  %x(p) is flow discharge in pipe "i"       
    vel(i) = x(p)/A(i); %vel (i) is velocity in pipe "i"
    Re = abs(vel(i))*D(i)/vis; %Reynolds Number in pipe "i"
    f(i) = 1.325/(log(eD(i)/3.7 + 5.74/Re^0.9))^2;   %Swamee�Jain equation for friction factor (we can also use Haaland equation instead)    
        %f(1) = 0.015;
        %f(2) = 0.019;
        %f(3) = 0.019;
        %f(4) = 0.02;
        %f(5) = 0.019;  
        %f(6) = 0.019;
        %f(7) = 0.017;
        %f(8) = 0.032;
     
    fLD =  f(i)*L(i)/D(i);
    A2_coeff = 2*g*(A(i))^2; %2gA(i)^2
    HLcof(i) = (fLD + Kinternal(i))/A2_coeff;
end
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

% Here you write the equations, using as variables x (1), x (2), etc
%Equations are written according with assumed flow directions
for i = 1:N   
    %Don't change this. The first N equations are already done
    p = 2*N + i;  %x(p) is flow discharge in pipe "i"
    q = N + i;     %x(q) is right head in pipe "i"
    
    if (Pump_at_conduit(i) == 1)
        hp =  A_pump(i) + B_pump(i)*abs(x(p)*1000.0) + C_pump(i)*1000.0^2*x(p)*x(p);  %hp = A + B*Q + C*Q^2 % hp[m], Q[m3/s]  
        if (hp < 0);
           hp = 0; 
        end
        if (x(p)> 0);
            F(i) = x(i)-x(q) - HLcof(i)*x(p)*abs(x(p)) + hp;
        else
            F(i) = x(i)-x(q) - HLcof(i)*x(p)*abs(x(p)) - hp;
        end
    else
        F(i) = x(i)-x(q) - HLcof(i)*x(p)*abs(x(p));
    end         
end   
 % F(M) M starts with N+1 (N = Number of pipes)
 %Equations at reservoirs  (Use Energy equation following assumed flow directions) 

%Equation of Continuity
i = N;
for j = 1:Number_nodes;
    if (Numb_pipes_at_a_node(j) >= 2);
        i = i+1;
        Q_temp = 0.0;
        for k = 1:Numb_pipes_at_a_node(j); %Number of pipes
            ID_of_pipe = ID_pipe_connected_to_a_Node(j,k); 
            if(Nodetype(j,k) ==2);%outflowing
                Q_temp = Q_temp-x(2*N+ID_of_pipe);
            else %inflowing
                Q_temp = Q_temp+x(2*N+ID_of_pipe);
            end
        end
        F(i) = Q_temp - Flow_Value_External_Node(j)/1000.0;
    end    
end   

%Free outflows at a node connected to a single pipe
for j = 1:Number_nodes;
    if (Free_outflow_at_Node(j) == 1); 
         i = i+1;
        ID_of_pipe = ID_pipe_connected_to_a_Node(j,1); 
        if(Nodetype(j,1) ==2);%outflowing
            F(i) = x(ID_of_pipe) - Elevation_of_node(j); 
        else   %inflowing
            F(i) = x(N+ID_of_pipe) - Elevation_of_node(j); 
        end             
    end    
end   


%Compatibility conditions of Energies at juntions
for j = 1:Number_nodes;
    if (Numb_pipes_at_a_node(j) >= 2);
        ID_of_pipe = ID_pipe_connected_to_a_Node(j,1); 
        if(Nodetype(j,1) ==2);%outflowing
            E_temp = x(ID_of_pipe) + (vel(ID_of_pipe))^2/(2*g); 
        else   %inflowing
            E_temp = x(N+ID_of_pipe) + (vel(ID_of_pipe))^2/(2*g); 
        end        
        
        for k = 2:Numb_pipes_at_a_node(j); %Number of pipes
            i = i+1;
            ID_of_pipe = ID_pipe_connected_to_a_Node(j,k); 
            if(Nodetype(j,k) ==2);%outflowing
                E_temp1 = x(ID_of_pipe) + (vel(ID_of_pipe))^2/(2*g);
            else %inflowing
                E_temp1 = x(N+ID_of_pipe) + (vel(ID_of_pipe))^2/(2*g); 
            end
            F(i) = E_temp - E_temp1;
        end
    end    
end  

%Reservoirs
for j = 1:Number_nodes;
        if (Reservoir_at_Node(j) == 1);             
            if (isnan(Water_Surface_elevation_Reservoir(j)) == 1);
                fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
                fprintf('\n ERROR at Node %d\D',j);
                fprintf('\n This node has been specified as a reservoir, however there is no water surface elevation data for this reservoir.');
                fprintf('\n Please specify in the Excel data the water surface elevation for this node');            
                fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');   
                STOPCODE = 1;
                break; 
            end          
                        
            ID_of_pipe = ID_pipe_connected_to_a_Node(j,1); 
            if(Nodetype(j,1) ==2); %outflowing
                E_temp = x(ID_of_pipe) + (vel(ID_of_pipe))^2/(2*g); 
            else %inflowing
                E_temp = x(N+ID_of_pipe) + (vel(ID_of_pipe))^2/(2*g); 
            end           
            
            i = i+1;
            if(Nodetype(j,1) ==2); %outflowing (Flow is assumed to LEAVE the reservoir )
                if(x(2*N+ID_of_pipe) >= 0.0); %positive flow
                    K_head_loss = KL(ID_of_pipe);
                else %negative flow
                    K_head_loss = 1.0;
                    %K_head_loss = 0.0;
                end
                F(i) = Water_Surface_elevation_Reservoir(j) - E_temp -K_head_loss*vel(ID_of_pipe)*abs(vel(ID_of_pipe))/(2*g);
            else %inflowing (Flow is assumed to ENTER the reservoir )
                if(x(2*N+ID_of_pipe) >= 0.0); %positive flow
                    K_head_loss = 1.0;
                    %K_head_loss = 0.0;
                    
                else %negative flow
                    K_head_loss = KR(ID_of_pipe);
                end
                F(i) = E_temp - Water_Surface_elevation_Reservoir(j) - K_head_loss*vel(ID_of_pipe)*abs(vel(ID_of_pipe))/(2*g);
            end   
        end   
end  

end

