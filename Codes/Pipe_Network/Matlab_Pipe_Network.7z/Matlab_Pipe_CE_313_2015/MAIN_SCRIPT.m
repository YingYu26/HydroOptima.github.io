% Created by Arturo Leon (Oregon State) for CE 313 (Hydraulic Engineering)
clear all; clear clc
format longG
close all;
%%Defining the global varialbles
global N; %Number of pipes
global vis; % Kinematic viscosity of fluid (m2/s)
global L; % data of lengths (in meters)
global D; % data of diameters (in meters)
global e; % data of roughness (in milimiters)
global Kinternal; % Minor losses at the interior of each pipe
global KL; % Minor losses at the left of each pipe (entrance conditions)
global KR; % Minor losses at the right of each pipe (exit conditions)
global g; %Gravity (SI)
global Number_nodes;
global Numb_pipes_at_a_node;
global ID_pipe_connected_to_a_Node;
global Nodetype;
global Reservoir_at_Node;
global Free_outflow_at_Node;
global Elevation_of_node;
global Water_Surface_elevation_Reservoir;
global Flow_at_Node;
global Flow_Value_External_Node; 
global STOPCODE;
global ORDERPLOT_row;
global Pump_at_conduit;
global A_pump;
global B_pump;
global C_pump;

%global double(Length_plot)

g = 9.8; %Gravity (SI)
STOPCODE = 0;

%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

%% INPUTS
filename = 'Pipe_Network_Handout_pipenet_network_page_10';
%filename = 'Ce313_demo_computer_lab.xlsx';

sheet = 1;
[ndata, text, A] = xlsread(filename);
%disp ('The data read from the excel spreadsheet is:')
%disp(A);

%% SOLUTION
% Finding the number of rows for various blocks of data
sizem=size(A);
rows_A=sizem(1);
for i=1:rows_A;
    if ( strcmp( A{i,1}, '[OPTIONS]')); 
            %fprintf('Your favorite animal is a type of dog!\n'); 
        OPTIONS_row = i;
        %fprintf('The OPTIONS row is %d\n',OPTIONS_row); 
    end 
    
    if ( strcmp( A{i,1}, '[NODES]'));             
        NODES_row = i;
        %fprintf('The nodes row is %d\n',NODES_row); 
    end 
    if ( strcmp( A{i,1}, '[CONDUITS]')); 
            %fprintf('Your favorite animal is a type of dog!\n'); 
        CONDUITS_row = i;
        %fprintf('The conduits row is %d\n',CONDUITS_row); 
    end 
    if ( strcmp( A{i,1}, '[RESERVOIRS]')); 
        RESERVOIRS_row = i;
        %fprintf('The RESERVOIRS row is %d\n',RESERVOIRS_row ); 
    end
    
    if ( strcmp( A{i,1}, '[FLOWS]'));
        FLOWS_row = i;
        %fprintf('The FLOWS row is %d\n',FLOWS_row); 
    end  
    
    if ( strcmp( A{i,1}, '[ORDERPLOT]'));
        ORDERPLOT_row = i;
        %fprintf('The FLOWS row is %d\n',FLOWS_row); 
    end
end

%Get Number of Nodes
j = 0;
for i= NODES_row + 4:CONDUITS_row - 1;   
    if (A{i,2} > -10^20);         
         j = j+1;
    end   
end
Number_nodes = j; %Number of Nodes
fprintf('The number of Nodes is %d\n',Number_nodes); 

%Get Number of Pipes
j = 0;
for i= CONDUITS_row + 4:RESERVOIRS_row - 1;      
    if (A{i,4} > 0);
         %disp(A(i,1));
         j = j+1;
    end   
end
N = j; %Number of pipes
fprintf('The number of pipes is %d\n',N); 

% Kinematic viscosity of fluid (m2/s) [Typically vis = 10^-6]
vis = cell2mat(A(OPTIONS_row+1,2));

j = 0;
Reservoir_at_Node = zeros(1,Number_nodes+1,'uint8');
Free_outflow_at_Node = zeros(1,Number_nodes+1,'uint8');
Pump_at_conduit = zeros(1,N+1,'uint8');
Flow_at_Node = zeros(1,Number_nodes+1,'uint8');
Node_plot = zeros(1,2*Number_nodes+1,'uint8');

Water_Surface_elevation_Reservoir(1,Number_nodes+1) = 0.0;
Flow_Value_External_Node(1,Number_nodes+1) = 0.0;
A_pump(1,N+1) = 0.0;
B_pump(1,N+1) = 0.0;
C_pump(1,N+1) = 0.0;
      

Inlet_Node = zeros(1,N+1,'uint8');
Outlet_Node = zeros(1,N+1,'uint8');
Conduit_side_plot = zeros(1,N+1,'uint8');

ALL_Node_string = cell(Number_nodes+1,1);
Node_plot_string = cell(2*Number_nodes+1,1);

Number_of_Reservoirs = 0;
Number_of_Flows_at_Nodes = 0;
Number_of_free_outflows = 0;
k = 0;
MM = 0;
NN = 0;
for i= NODES_row + 4:NODES_row + 4 + Number_nodes - 1;
    j = j+1;
    ID_of_Nodes(j) = j;    
    S1 = num2str(A{i,1});
    ALL_Node_string{j} = num2str(A{i,1});
    if (strcmp(A{i,3}, 'YES')); 
        k = k+1;
        Reservoir_at_Node(j)= 1;   
        Number_of_Reservoirs = k;
    end
    if (strcmp( A{i,4}, 'YES')); 
        MM =  MM+1;
        Number_of_Flows_at_Nodes = MM;
        Flow_at_Node(j)= 1;        
    end
    if (strcmp( A{i,5}, 'YES')); 
        NN =  NN+1;
        Number_of_free_outflows  = NN;
        Free_outflow_at_Node(j)= 1;        
    end
    
    Elevation_of_node(j) = cell2mat(A(i,2));
end  

%Identifying Node IDs of Reservoirs 
 for i = 1: Number_of_Reservoirs;
    M_ID = RESERVOIRS_row + 3 + i;
    s1 = num2str(A{M_ID,1});
    for k = 1: Number_nodes;
        s2 = num2str(ALL_Node_string{k});
       if (strcmp(s2,s1)); 
            Water_Surface_elevation_Reservoir(k) = cell2mat(A(M_ID,2));
        end
    end
 end
 
 %Identifying Node IDs of External Flows 
 for i = 1: Number_of_Flows_at_Nodes;
    M_ID = FLOWS_row + 3 + i;
    s1 = num2str(A{M_ID,1});
    for k = 1: Number_nodes;
        s2 = num2str(ALL_Node_string{k});
       if (strcmp(s2,s1)); 
           Flow_Value_External_Node(k) = cell2mat(A(M_ID,2));
        end
    end
 end  
 
j = 0;
Inlet_Node_string = cell(N+1,1);
Outlet_Node_string = cell(N+1,1);
CONDUIT_STRING_ID = cell(N+1,1);



%char(zeros(POPULATION_SIZE,NO_PARAMETERS*NO_BITS_PATAMETER));
%Outlet_Node_string = char(N+1)
k = 0;
for i= CONDUITS_row + 4:CONDUITS_row + 4 + N - 1;
    j = j+1;
    S1 = num2str(A{i,1});
    CONDUIT_STRING_ID{j} = S1;
    S1 = num2str(A{i,2});
    S2 = num2str(A{i,3});
    Inlet_Node_string{j} = S1;
    Outlet_Node_string{j} = S2;
    if (strcmp(A{i,10}, 'YES')); 
        k = k+1;
        Pump_at_conduit (j)= 1; 
        A_pump(j) = cell2mat(A(i,11));
        B_pump(j) = cell2mat(A(i,12));
        C_pump(j) = cell2mat(A(i,13));
        Number_of_Pumps = k;
    end
    
    D(j) = cell2mat(A(i,4));
    L(j) = cell2mat(A(i,5));
    e(j) = cell2mat(A(i,6));
    Kinternal(j) = cell2mat(A(i,7));
    KL(j) = cell2mat(A(i,8)); %K exit from reservoir (K entrance to reservoir is always 1) 
    KR(j) = cell2mat(A(i,9)); %K exit from reservoir (K entrance to reservoir is always 1) 
end  


j = 0;
 for i = 1: N;    
    for k = 1: Number_nodes;
        M_ID = NODES_row + 3 + k;
        s1 = num2str(A{M_ID,1});
        s2 = num2str(Inlet_Node_string{i}); 
        if (strcmp(s2,s1) == 1); %0 if they are not the same, 1 if they are the same      
            Inlet_Node(i) = k;
        end
    end
 end
 
 
 for i = 1: N;
    for k = 1: Number_nodes;
        M_ID = NODES_row + 3 + k; 
        s1 = num2str(A{M_ID,1});
        s2 = num2str(Outlet_Node_string{i});         
        if (strcmp(s2,s1) == 1); %0 if they are not the same, 1 if they are the same    
            Outlet_Node(i) = k;
        end
    end
 end
 
j = 0;

for i= ORDERPLOT_row + 2:rows_A;   
    s1 = num2str(A{i,1});    
    if (strcmp(s1, 'NaN') == 0);     %0 if they are not the same, 1 if they are the same
        j = j+1;
    end
    
end  
Number_of_nodes_to_plot = j;

%To determine number of inflowing and outflowing pipes and to count the number of pipes at each node
Numb_pipes_at_a_node = zeros(1,N+1,'uint8');
Numb_outflowing_pipes_at_a_node = zeros(1,N+1,'uint8');
Numb_inflowing_pipes_at_a_node = zeros(1,N+1,'uint8');
ID_pipe_connected_to_a_Node = zeros(N+1,10,'uint8');
ID_pipe_connected_to_a_Node(N+1,10) = 0;

for k =1: N;  %N is Number of pipes
    %At Inlet
    %fprintf('Pipe ID is %d\n',k); 
    i = Inlet_Node(k); 
    Numb_pipes_at_a_node(i) = Numb_pipes_at_a_node(i)+1;
    R = Numb_pipes_at_a_node(i); 
    ID_pipe_connected_to_a_Node(i,R) = k;  
    Numb_outflowing_pipes_at_a_node(i) = Numb_outflowing_pipes_at_a_node(i)+1;    
    Nodetype(i,R) = 2; %outflowing
    
    %At Outlet
    i = Outlet_Node(k); 
    Numb_pipes_at_a_node(i) = Numb_pipes_at_a_node(i)+1;
    R = Numb_pipes_at_a_node(i);
    ID_pipe_connected_to_a_Node(i,R) = k;     
    Numb_inflowing_pipes_at_a_node(i) = Numb_inflowing_pipes_at_a_node(i)+1;        
    Nodetype(i,R) = 1; %inflowing    Yes 
end
  

%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

%Length_plot(Number_of_nodes_to_plot,1)= 0.0
%Identify the IDs of pipes to plot
 for i = 1: Number_of_nodes_to_plot;
    M_ID = ORDERPLOT_row + 1 + i;
    for k = 1: Number_nodes;
        if(A{M_ID,1} == ALL_Node_string{k});            
            Node_plot(i) = k;
            Node_plot_string{i} = ALL_Node_string{k};
        end
    end
 end
 
 var_temp = 2*(Number_of_nodes_to_plot-1);
 %Var_temp = Number_of_nodes_to_plot + Number_of_nodes_to_plot+1;
 Length_plot(var_temp) = 0.0;
 Z_node(var_temp) = 0.0;
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
 if (Number_of_nodes_to_plot < 2);
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    %fprintf('\n Specify at least 2 nodes for plotting');
    error('Specify at least 2 nodes for plotting. Check Excel File') 
    %break  
 end
 
 %To know which pressures to plot in each pipe (left or right)
 %AAAAAA =  Node_plot(1)
j = 0;
M_check = zeros(Number_of_nodes_to_plot,1,'uint8');
 for i = 1: Number_of_nodes_to_plot;
     NodePlot1 = Node_plot(i);    
    for k = 1: N %Number of Conduits        
        if (Node_plot(i) == Inlet_Node(k) & Node_plot(i+1) == Outlet_Node(k));
            Conduit_plot(i) = k;
            j = j+2;
            M_check(i) = 1; M_check(i+1) = 1; 
            for qq = 1: Numb_pipes_at_a_node(NodePlot1); %Number of Conduits
                if (ID_pipe_connected_to_a_Node(NodePlot1,qq) == k);
                   if (Nodetype(NodePlot1,qq) == 1); %outflowing   Left 1, Right 2
                        Conduit_side_plot(j-1) = 2;
                        Conduit_side_plot(j) = 1;
                   else
                        Conduit_side_plot(j-1) = 1;
                        Conduit_side_plot(j) = 2;
                   end
                end
            end
            if (j <= 2);
                Length_plot(j-1) = 0;
                Length_plot(j) = Length_plot(j-1) + L(k);            
            else
                Length_plot(j-1) = Length_plot(j-2);
                Length_plot(j) = Length_plot(j-1) + L(k);
            end
            Z_node(j-1) = Elevation_of_node(Node_plot(i));
            Z_node(j) = Elevation_of_node(Node_plot(i+1));  
            
        elseif (Node_plot(i) == Outlet_Node(k) & Node_plot(i+1) == Inlet_Node(k));
            Conduit_plot(i) = k;
            j = j+2;
            M_check(i) = 1; M_check(i+1) = 1; 
            for qq = 1: Numb_pipes_at_a_node(NodePlot1); %Number of Conduits
                if (ID_pipe_connected_to_a_Node(NodePlot1,qq) == k);
                   if (Nodetype(NodePlot1,qq) == 1); %outflowing   Left 1, Right 2
                        Conduit_side_plot(j-1) = 2;
                        Conduit_side_plot(j) = 1;
                   else
                        Conduit_side_plot(j-1) = 1;
                        Conduit_side_plot(j) = 2;
                   end
                end
            end
            if (j <= 2);
                Length_plot(j-1) = 0;
                Length_plot(j) = Length_plot(j-1) + L(k); 
            else
                Length_plot(j-1) = Length_plot(j-2); 
                Length_plot(j) = Length_plot(j-1) + L(k);
            end
            Z_node(j-1) = Elevation_of_node(Node_plot(i));
            Z_node(j) = Elevation_of_node(Node_plot(i+1));            
            
        %else 
            %fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
            %fprintf('\n The nodes to plot must be continuous. Check the data');
            %break
        end 
    end
    
    if (M_check(i) == 0);
        fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
        %fprintf('\n There are errors in assigning the node data for plotting. The nodes must be continuous');
        error('Error: There are errors in assigning the node data for plotting. The nodes must be continuous') 
        %break  
    end        
 end 
 

%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%%Don't modify anything below 
r = 3*N;
x0(1:r) = 1;
Tolerance = 1e-7; %Tolerance of calculations
options = optimset('Display','iter','TolX',Tolerance);
options.MaxFunEvals = 100000000;
[x,fval] = fsolve (@myfun_3pipes,x0,options); % To Call solver 
 
fprintf('\n  j              x(j)\n');
x = x';
for i = 1:3*N;    
    fprintf('%3d %20.8f \n',i,x(i));
    %fprintf('%3d %20.5f %20.5f %20.5f\n',i,Left_heads(i),Right_heads(i),Flows(i));
end

fprintf('\n  j       Residual j\n');
fval = fval';
SUM_ERROR = 0.0; %
for i = 1:3*N;    
   fprintf('%3d %20.16f \n',i,fval(i));
   SUM_ERROR = SUM_ERROR +  abs(fval(i));
end


if (STOPCODE ==1);
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    %fprintf('\n There were errors in the computations');
    %break  
    error('Error: There were unknown errors in the computations')     
elseif (SUM_ERROR > 3.0*N*Tolerance); 
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    %fprintf('\n There were errors in the computations');
    %break 
    error('There is convergence errors in the computations')
else
    %Hydraulic Grade Line
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    fprintf('\n Hydraulic Grade Line (Pressure head + Elevation head) \n');
    fprintf('\n pipe  	Left head H_L    Right head H_R     Discharge  	     Velocity head\n');
    fprintf('               [m]               [m]            [L/s]             [m] \n');
    for i = 1:N; 
        s1 =   CONDUIT_STRING_ID{i};    
        area = pi*D(i)^2.0/4.0;
        vel_head = 1.0/(2.0*g*area^2.0)*(x(2*N+i))^2.0;
        fprintf('%s %15.5f %15.5f %15.5f %15.5f\n',s1,x(i),x(N+i),x(2*N+i)*1000,vel_head);        
    end
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n');

    %Energy Grade Line
    fprintf('Energy Grade Line (Pressure head + Elevation head + Velocity head)\n');
    fprintf('\n pipe  Left total head  Right total head     Discharge  	     Velocity head\n');
    fprintf('               [m]               [m]            [L/s]             [m] \n');
    for i = 1:N; 
        s1 =   CONDUIT_STRING_ID{i};    
        area = pi*D(i)^2.0/4.0;
        vel_head = 1.0/(2.0*g*area^2.0)*(x(2*N+i))^2.0;
        total_head_left = x(i) + vel_head;
        total_head_right = x(N+i) + vel_head;
        fprintf('%s %15.5f %15.5f %15.5f %15.5f\n',s1,total_head_left,total_head_right,x(2*N+i)*1000,vel_head);  
        
        %fprintf('Today is %s\n',datestr(now));
        
    end
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& \n');

    %Energy 
    Plot_HGL_and_EGL(N,x,D,Length_plot,Z_node,CONDUIT_STRING_ID,Conduit_plot,Conduit_side_plot,Number_of_nodes_to_plot,Node_plot_string,g)
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& \n');
    fprintf('\n CONGRATULATIONS!');
    fprintf('\n The computation appears to be SUCCESFUL!');
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&');
    fprintf('\n &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& \n');        
end
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$