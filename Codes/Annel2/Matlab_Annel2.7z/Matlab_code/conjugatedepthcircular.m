                    te = 2*acos(1-2*d1/d(e));    
                    A = 1/8*(te-sin(te))*d(e)^2;
                    pe = 0.5*te*d(e);
                    T = sin(te/2)*d(e);
                    v1 = (Q/A);
                    
                    ff1 = Q*v1+9.8*((d(e)-d1)*d1*(3*d(e)^2-4*d(e)*d1+4*d1^2)-3*d(e)^2*(d(e)-2*d1)*(d(e)-d1)^(1/2)*(d1)^(1/2)*atan((d1/(d(e)-d1))^(1/2)))...
                        /(12*((d(e)-d1)*(d1))^(1/2));
                        
                            d2=1.2*yc(e);
                            for i =1:num_itera;
                                te = 2*acos(1-2*d2/d(e));    
                                A = 1/8*(te-sin(te))*d(e)^2;
                                pe = 0.5*te*d(e);
                                T = sin(te/2)*d(e);
                                v2 = (Q/A);
                                
                                f = Q*v2+9.8*((d(e)-d2)*d2*(3*d(e)^2-4*d(e)*d2+4*d2^2)-3*d(e)^2*(d(e)-2*d2)*(d(e)-d2)^0.5*d2^0.5*atan((d2/(d(e)-d2))^0.5))...
                                    /(12*((d(e)-d2)*(d2))^0.5)-ff1;
                                df=-Q^2*A^-2*T+9.8*(-(d(e)-2*d2)*(d(e)-d2)*d2+d(e)^2*(d(e)-d2)^0.5*d2^0.5*atan((d2/(d(e)-d2))^0.5))/(2*(d(e)-d2)^0.5*d2^0.5);
                                d2=d2-f/df;
                                
                                            if ((i>num_itera-2) & d2>=0.99*d(e));                                                                                             
                                                d2=0.99*d(e);                                           
                                                break
                                            end
                                           if (abs(f/df)/(d2 - 0.5*f/df)<tol); 
                                                d2=d2;                                           
                                                break
                                            end
                            end  