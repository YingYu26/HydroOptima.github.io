 %Starting section of computation
                    dd = q;
                    k= dd;
                    e = dd+1;
                    d1 = eval(['y',int2str(k),'(p(k)+1);']);
                    yyy=d1;
                    if cha == 'c';
                        conjugatedepthcircular;
                    else
                        conjugatedepthtrapez; %Subroutine for the computation of the conjugate depth
                    %Without considering the length of the hydraulic jump. 
                    end
                    yy=eval(['y',int2str(e),'(1);']); 
                if(d2>yy);
                    rr=p(dd)+2;
                    yy1 = yyy;
                    zz = eval(['z',int2str(e),'(1);']);
                        if cha == 'c';
                            te = 2*acos(1-2*yy1/d(e));
                            A = 1/8*(te-sin(te))*d(e)^2;
                            pe = 0.5*te*d(e);
                        else
                            A = (b(e)+zt(e)*yy1)*yy1;
                            pe = b(e)+2*yy1*(1+zt(e)^2)^(1/2);
                        end
                    v2 = (Q/A)^2/(2*9.8);
                    ar= 1/n(e)*A^(5/3)/pe^(2/3);
                    E11 = zz+yy1*ss(e)+v2;
                    sf11=(Q/ar).^2;
                    v = dd;
                    c = 0;
                    tt = c;
                            while v <=NU-1;
                                    if (w(v+1) == 0)&(c==tt);  
                                            q = q+1;    
                                            k = v;
                                            e = v+1;
                                            tt = round(L(e)/dx(dd));
                                            yd(e) = eval(['y',int2str(e),'(p(e)+1);']);
                                        for c = 1:tt;
                                                jumpM3;
                                                if cha == 'c';
                                                    conjugatedepthcircular;
                                                else
                                                    conjugatedepthtrapez;
                                                end
                                            L(e)=L(e)-dx(dd);   
                                            p(e) = round(max(L(e)/20,100));                                            
                                            dx(e) = L(e)/p(e);
                                            mm1 = eval(['m',int2str(dd),'(rr);']); 
                                            zz1 = eval(['z',int2str(dd),'(rr);']); 
                                            
                                            sti = int2str(e);  %This is modified
                                            clear (['y', sti]);
                                            clear (['m', sti]);
                                            clear (['z', sti]);
                                            eval(['m',int2str(e),'(1)','= mm1;']);                                            
                                            eval(['z',int2str(e),'(1)','= zz1;']); 
                                            
                                                if cha == 'c';
                                                    backwsubcrcircular,
                                                else
                                                    backwsubcrtrapez;
                                                end                                            
                                            y23 = eval(['y',int2str(e),'(1);']); 
                                                        if d2<y23; 
                                                        eval(['y',int2str(dd),'(rr)','= y23;']);                                                  
                                                            break
                                                        end                                                        
                                                        rr=rr+1; 
                                        end    
                                    else 
                                        break
                                    end 
                                     v = v+1;
                            end
                else
                    %Conjugate depth computation
                    k = dd;
                    gg=(p(k)+1)-1; 
                    yd(k) = eval(['y',int2str(k+1),'(1);']); 
                    zz1 = eval(['z',int2str(k+1),'(1);']); 
                            
                    eval(['y',int2str(k),'(p(k)+1)','= yd(k);']); 
                    
                    yy =yd(k);
                    h = 2;
                    e = dd;
                        if cha == 'c';
                            te = 2*acos(1-2*yy/d(e));
                            A = 1/8*(te-sin(te))*d(e)^2;
                            pe = 0.5*te*d(e);
                        else
                            A = (b(e)+zt(e)*yy)*yy;
                            pe = b(e)+2*yy*(1+zt(e)^2)^(1/2);
                        end          
                    v2 = (Q/A)^2/(2*9.8);
                    ar= 1/n(e)*A^(5/3)/pe^(2/3);
                    E2 = zz1+yy*ss(e)+v2;
                    sf2=(Q/ar).^2;
                    for j=1:p(k);
                    d1 = eval(['y',int2str(k),'(gg);']);
                            jumpS1;%Computation of S1 profile
                            if cha == 'c';
                                conjugatedepthcircular;
                            else
                                conjugatedepthtrapez;
                            end
                       y22 = eval(['y',int2str(k),'(gg);']); 
                        if(d2>y22);
                            break 
                        end
                    h = h+1;
                    gg = gg - 1;
                    end
                    q = q+1;
                end
                