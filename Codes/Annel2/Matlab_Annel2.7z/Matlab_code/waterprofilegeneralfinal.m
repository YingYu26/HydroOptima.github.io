%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Water Surface profile for Circular, Rectangular, Triangular and Trapezoidal channels
%Programmed by Arturo Leon at UIUC (2003) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for k = 1:NU;
    ss(k) = cos(atan(abs(s(k))));
end
for k = 1:NU;
    L(k)=round(L(k));
end

if NU == 1;  %Because code work with a minimum of two pipes
    NU = 2;
    L(1) = L(1)/2;
    L(2)= L(1);
    ss(2) = ss(1);
    s(2) = s(1); 
    b(2) = b(1); 
    n(2) = n(1); 
    zt(2) = zt(1); 
end
  

if cha == 'c';
%critical and normal depth and Boundary setup
    critnormaltdepthcircular;
else 
    critnormaltdepthtrapez
    
end

%Step distance computation
k = 1;
while k <= NU;
    p(k) = round(max(L(k)/20,100));
    dx(k) = L(k)/p(k);
    k = k+1;
end

%For Hydraulic jump computation 
 for g = 1:NU;
    if F(g)>1;
        w(g)=1;
    else
        w(g)=0;
    end
end
m1(1) = STA;
z1(1) = ELEV; 
mp(1) = m1(1);
zp(1) = z1(1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    for j = 1:NU; 
                        mm = eval(['m',int2str(j),'(1);']); 
                        mm1 = mm + L(j);
                        eval(['m',int2str(j+1),'(1)','= mm1;']);
                        eval(['m',int2str(j),'(p(j)+1)','= mm1;']);
                        
                        zz = eval(['z',int2str(j),'(1);']); 
                        zz1 = zz -s(j)*L(j);
                        eval(['z',int2str(j+1),'(1)','= zz1;']);
                        eval(['z',int2str(j),'(p(j)+1)','= zz1;']);
                        
                        mp(j+1) = mm+ L(j);
                        zp(j+1) = zz-s(j)*L(j);
                        
                    end 
                    mp(NU+1) = mp(NU)+L(NU);
                    zp(NU+1) = zp(NU)-s(NU)*L(NU);
                    
                    %Critical depth, Normal depth drawing 
            
                    c = 0;
                    for i = 1: NU;
                        mm = eval(['m',int2str(i),'(1);']); 
                        mm1 = eval(['m',int2str(i),'(p(i)+1);']);
                        zz = eval(['z',int2str(i),'(1);']); 
                        zz1 = eval(['z',int2str(i),'(p(i)+1);']);
                        
                        mr(c+1)=mm;
                        mr(c+2)=mm1;
                        ycc(c+1)=yc(i)+zz;
                        ycc(c+2)=yc(i)+zz1;
                        ynn(c+1)=yn(i)+zz;
                        ynn(c+2)=yn(i)+zz1;
                        
                        c = c+2;
                    end                    
if cha == 'c';
    c = 0;
                    for i = 1: NU;
                        zz = eval(['z',int2str(i),'(1);']); 
                        zz1 = eval(['z',int2str(i),'(p(i)+1);']);
                        zr(c+1)=zz+d(i);
                        zr(c+2)=zz1+d(i);
                        c = c+2;
                    end 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Starting of computations       
    e = NU; %Standar step subcritical back water profile computation modified       
    y1(1)=yupst; 
    yd(e)=ydown; 
    while e >= 1;
            if F(e)<1;  
                if cha == 'c';
                    backwsubcrcircular;  
                else 
                    backwsubcrtrapez;  
                end 
                            if e > 1; 
                                if (F(e-1)<1); 
                                    yd(e-1) = eval(['y',int2str(e),'(1);']);
                                end
                            end
                 e = e-1;  
            else
                                if e > 1; 
                                    if F(e-1)<1; 
                                        yd(e-1) = Constant_for_Y_SUPER*max(yc(e-1),yc(e));
                                        eval(['y',int2str(e),'(1)','= Constant_for_Y_SUB*min(yc(e-1),yc(e));']);
                                    end
                                end
                                e = e-1;
            end 
    end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
   %Standar step supercritical back water profile computation
    e = 1;
    while e <= NU;
            if F(e)>1; 
                if cha == 'c';
                    backwsupercrcircular;
                else 
                    backwsupertrapez;
                end 
                            if e<=NU-1;
                                    if F(e+1)>1;
                                        temp = eval(['y',int2str(e),'(p(e)+1);']);
                                        eval(['y',int2str(e+1),'(1)','= temp;']);
                                    end
                            end
            e = e+1;
            else 
            e = e+1; 
            end 
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Computation from downstream to upstream. It verifies if the downstream water depth drowns the upstream water depth
e = NU;          
                        while e>=2;
                                ER1 = eval(['EN',int2str(e),'(1);']); 
                                ER2 = eval(['EN',int2str(e-1),'(1);']); 
                                if ER2<ER1;
                                    e =e-1;
                                    yd(e) = eval(['y',int2str(e+1),'(1);']);
                                    mm8 = eval(['m',int2str(e),'(1);']); 
                                    zz8 = eval(['z',int2str(e),'(1);']);                                    
                                        sti = int2str(e);
                                        clear (['y', sti]);
                                        clear (['m', sti]);
                                        clear (['z', sti]);
                                    eval(['m',int2str(e),'(1)','= mm8;']); 
                                    eval(['z',int2str(e),'(1)','= zz8;']); 
                                    p(e) = round(max(L(e)/20,60));
                                    
                                    dx(e) = L(e)/p(e);
                                    w(e)=0;                                  
                                   
                                   
                                                    if cha == 'c';
                                                            backwsubcrcircular;      
                                                    else
                                                            backwsubcrtrapez;
                                                    end  
                                                    
                                                    if (F(e-1) < 1 & e>=2);
                                                            e = e-1;
                                                            yd(e) = eval(['y',int2str(e+1),'(1);']);
                                                            w(e)=0;
                                                            if cha == 'c';
                                                                backwsubcrcircular;      
                                                            else
                                                                backwsubcrtrapez;
                                                            end
                                                    end                                    
                                else 
                                    e = e-1;                                    
                                end                                      
                        end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 %Hydraulic Jump Computation
 c = 0;
 tt = -1;
 q =1;   
            while q<=NU-1;                 
                if (w(q)==1 & w(q+1)==0 ); 
                        hydrjump;
                end                 
                q=q+1;
                                if ((q<=NU)&(w(q)==1)&(c==tt));
                                        e = q;
                                        yy6 = eval(['y',int2str(dd),'(rr-1);']);
                                        eval(['y',int2str(e),'(1)','= yy6;']); 
                                                if cha == 'c';
                                                    backwsupercrcircular;
                                                else
                                                    backwsupertrapez;
                                                end
                                        
                                            while q<=NU-1;
                                                if w(q+1)==1; 
                                                    q = q+1;
                                                    e = q;
                                                    yy6 = eval(['y',int2str(e-1),'(p(e-1)+1);']);
                                                    eval(['y',int2str(e),'(1)','= yy6;']); 
                                                        if cha == 'c';
                                                            backwsupercrcircular;
                                                        else
                                                            backwsupertrapez;
                                                        end
                                                else 
                                                    break
                                                end
                                            end
                                end
            end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %To make sure that after hydraulic jump computations, the ending water
    %level of the first reach  matches the starting water level of the second
    %reach
    e = 2; 
    if w(e-1) == 0 & w(e) == 1;
        ytemp1 = eval(['y',int2str(e-1),'(p(e-1)+1);']);
      	ytemp2 = eval(['y',int2str(e),'(1);']);
     	if ytemp1 > yc(e-1)   &  ytemp2 > yc(e);
           	yd(e-1) = ytemp2;
           	e = e-1;
         	if cha == 'c';
               	backwsubcrcircular;  
            else 
              	backwsubcrtrapez;  
            end 
       	end
    end
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gg = max (eval(['y',int2str(1),'(:);'])); 

ff  = max(yc);
mm = max(gg,ff);
%filebasew = 'C:\Waterprofileresults';% Filebase name where the data will be sent
%filesave = fopen([filebasew '.dat'],'w');
%fprintf(filesave,'    Station(m)      water depth(m)\n');

%for i = 1:NU
    %for j = 1: p(i)
        %fprintf(filesave,'%8.0f %15.3f\n',eval(['m',int2str(i),'(j)']),eval(['y',int2str(i),'(j)']));
        
    %end
%end 
%fclose(filesave);
hold off
if cha == 'c' %Circular Channel
    whitebg('white');
    set(gcf,'Color',[0.6,0.8,1]);
% screen_size = get(0, 'ScreenSize');     %1/2)this function will maximize the plot window
% set(figure, 'Position', [0 0 screen_size(3) screen_size(4) ] );   %2/2)this function will maximize the plot window
    plot(mp,zp,'ko-','LineWidth',5);
    hold on
    plot(mr,zr,'go-','LineWidth',5);
    hold on
    plot(mr,ycc,'r--',mr,ynn,'m--'),xlabel('\bf Station (m)'),ylabel('\bf Elevation (m)'),grid on, ...
    hold on    
    axis([m1(1)  mp(NU+1) min(zp(:))  max(zp(:))+max(d)]),title('WATER SURFACE PROFILE'),
    hold on
        for i = 1:NU
            plot(eval(['m',int2str(i),'(:)']),eval(['y',int2str(i),'(:)'])+eval(['z',int2str(i),'(:)']),'b-', 'LineWidth',1.9);
            %hold on
        end        
    legend('Bottom of Tunnel or pipe','Top of Tunnel or pipe', 'Critical depth line','Normal depth line','Water surface profile','Location','SW');
    hold off  
else %TRAPEZOIDAL
    plot(mp,zp,'ko-','LineWidth',7);
    hold on
    plot (mr,ycc,'m:','LineWidth',3);
    hold on
    plot (mr,ynn,'r--','LineWidth',3);    
    hold on
    xlabel('\bf Station (m)'),ylabel('\bf Elevation (m)'),grid on, ...
    axis([m1(1)  mp(NU+1) min(zp(:))  max(zp(:))+1.10*mm]),title(' '),
    hold on
        for i = 1:NU
            plot(eval(['m',int2str(i),'(:)']),eval(['y',int2str(i),'(:)'])+eval(['z',int2str(i),'(:)']),'b-', 'LineWidth',3.0);
            %hold on
        end
    legend('Bottom of Channel', 'Critical depth line','Normal depth line','Water surface profile','Location','SW');
    hold off
end

hold off

%end of program