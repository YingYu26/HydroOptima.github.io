%Supercritical
 %initial
                    yy = eval(['y',int2str(e),'(1);']);
                    zz = eval(['z',int2str(e),'(1);']); 
                    te = 2*acos(1-2*yy/d(e));
                    A = 1/8*(te-sin(te))*d(e)^2;
                    pe = 0.5*te*d(e);
                    v2 = (Q/A)^2/(2*9.8);                    
                    ar= 1/n(e)*A^(5/3)/pe^(2/3);                    
                    E1 = zz+yy*ss(e)+v2;
                    sf1=(Q/ar).^2;
                    %Streamwise
                    h = 2;
                    while h <= p(e)+1;
                        yy = eval(['y',int2str(e),'(h-1);']);                         
                        mm = eval(['m',int2str(e),'(1);']); 
                        mm1 = mm + (h-1)*dx(e);
                        zz1 = zz-s(e)*(mm1-mm);
                        eval(['m',int2str(e),'(h)','= mm1;']);
                        eval(['z',int2str(e),'(h)','= zz1;']);
                            for i =1:num_itera;
                            te = 2*acos(1-2*yy/d(e));
                            A = 1/8*(te-sin(te))*d(e)^2;
                            pe = 0.5*te*d(e);        
                            R = A/pe;
                            T = sin(te/2)*d(e); 
                            v2 = (Q/A)^2/(2*9.8);
                            ar= 1/n(e)*A^(5/3)/pe^(2/3);
                            E2 = zz1+yy*ss(e)+v2;
                            sf2=(Q/ar).^2;
                            f = E2-E1+(sf1*sf2)^0.5*dx(e); %Geometric mean friction slope
                            df = 1-Q^2/9.8*T/A^3+dx(e)/2*sf1^0.5*sf2^(-0.5)*Q^2*n(e)^2*(-10/3*pe^(4/3)*A^(-13/3)*T+(8/3)*A^(-10/3)*pe^(1/3)*(1-(1-2*yy/d(e))^2)^-0.5);
                            yy=yy-f/df;                                                                                        
                                                        if ((i>num_itera-2) & (yy>=0.98*d(e)));
                                                                eval(['y',int2str(e),'(h)','= d(e);']); 
                                                                yy = 0.98*d(e);
                                                                te = 2*acos(1-2*yy/d(e));    
                                                                A = 1/8*(te-sin(te))*d(e)^2;
                                                                pe = 0.5*te*d(e);
                                                                R = A/pe;
                                                                v2 = (Q/A)^2/(2*9.8);
                                                                ar= 1/n(e)*A^(5/3)/pe^(2/3);
                                                                E2 = zz1+yy*ss(e)+v2;
                                                                sf2=(Q/ar).^2;
                                                                break                                                                
                                                        end 
                            
                                            if (abs(f/df)/(yy - 0.5*f/df)<tol);
                                                eval(['y',int2str(e),'(h)','= yy;']); 
                                                break
                                            end
                            end
                        sf1=sf2;
                        E1=E2;
                        h=h+1;
                    end
                    yy5 = eval(['y',int2str(e),'(1);']);
                    te = 2*acos(1-2*yy5/d(e));    
                    A = 1/8*(te-sin(te))*d(e)^2;
                    v2 = (Q/A)^2/(2*9.8);
                    zz5 = eval(['z',int2str(e),'(1);']);
                    EE5 = yy5*ss(e)+v2+zz5;
                    eval(['EN',int2str(e),'(1)','= EE5;']); 
                    
                    
                    yy6 = eval(['y',int2str(e),'(p(e)+1);']);                    
                    te = 2*acos(1-2*yy6/d(e));    
                    A = 1/8*(te-sin(te))*d(e)^2;
                    v2 = (Q/A)^2/(2*9.8);
                    zz6 = eval(['z',int2str(e),'(p(e)+1);']); 
                    EE6 = yy6*ss(e)+v2+zz6;
                    eval(['EN',int2str(e),'(2)','= EE6;']); 
                    

                    