   %Streamwise
                    
                    yy1 = eval(['y',int2str(e),'(p(e)+3-h);']);   
                    zz2 = eval(['z',int2str(e),'((p(e)+2-h));']); 
                            for i = 1:num_itera;
                               if cha == 'c';
                                    te = 2*acos(1-2*yy1/d(e));    
                                    A = 1/8*(te-sin(te))*d(e)^2;
                                    pe = 0.5*te*d(e);
                                    T = sin(te/2)*d(e); 
                                else 
                                    A = (b(e)+zt(e)*yy1)*yy1;
                                    pe = b(e)+2*yy1*(1+zt(e)^2)^(1/2);
                                    T = b(e)+2*zt(e)*yy1;
                                end  
                            R = A/pe; 
                            v2 = (Q/A)^2/(2*9.8);
                            ar= 1/n(e)*A^(5/3)/pe^(2/3);
                            E1 = zz2+yy1*ss(e)+v2;
                            sf1=(Q/ar).^2;
                            
                            f = E2-E1+0.5*(sf1+sf2)*dx(e); %Aritmetic mean friction slope
                            
                                if cha == 'c';                                    
                                    df = -(1-Q^2/9.8*T/A^3)+dx(e)/2*Q^2*n(e)^2*(-10/3*pe^(4/3)*A^(-13/3)*T+(8/3)*A^(-10/3)*pe^(1/3)*(1-(1-2*yy1/d(e))^2)^(-1/2));
                                else 
                                    df = -(1-Q^2/9.8*T/A^3)+dx(e)/2*Q^2*n(e)^2*(-10/3*pe^(4/3)*A^(-13/3)*T+(4/3)*A^(-10/3)*pe^(1/3)*(2*(1+zt(e)^2)^0.5));
                                end                             
                            yy1= yy1-f/df;                                                             
                                                            if ((cha == 'c')& (yy1>=0.98*d(e)) & (i>num_itera-2)); 
                                                                eval(['y',int2str(e),'(p(e)+2-h)','= 0.98*d(e);']); 
                                                                yy1 = Constant_for_Y_SUB*d(e);
                                                                te = 2*acos(1-2*yy1/d(e));    
                                                                A = 1/8*(te-sin(te))*d(e)^2;
                                                                pe = 0.5*te*d(e); 
                                                                R = A/pe;
                                                                v2 = (Q/A)^2/(2*9.8);
                                                                ar= 1/n(e)*A^(5/3)/pe^(2/3);
                                                                E1 = zz2+yy1*ss(e)+v2;
                                                                sf1=(Q/ar).^2;
                                                                break
                                                            end                                                             
                                                            
                                                            if (abs(f/df)/(yy1 - 0.5*f/df)<tol);
                                                                    eval(['y',int2str(e),'(p(e)+2-h)','= yy1;']); 
                                                            break
                                            end
                            end
                    sf2=sf1;
                    E2=E1;