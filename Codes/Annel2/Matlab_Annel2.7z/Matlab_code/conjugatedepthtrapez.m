

                    A = (b(e)+zt(e)*d1)*d1;
                    v1 = (Q/A);
                    ff1 = Q*v1+9.8*(b(e)*d1^2/2+1/3*zt(e)*d1^3);
                            d2=4*yc(e);
                            for i =1:num_itera;
                            A=(b(e)+zt(e)*d2)*d2;
                            f=Q^2/((b(e)+zt(e)*d2)*d2) + 9.8*(b(e)*d2^2/2 + 1/3*zt(e)*d2^3)-ff1;
                            df=-Q^2*zt(e)/((b(e) + zt(e)*d2)^2*d2)-Q^2/((b(e)+zt(e)*d2)*d2^2)+ 9.8*(b(e)*d2+zt(e)*d2^2);
                            d2=d2-f/df;
                                            if (abs(f/df)/(d2 - 0.5*f/df)<tol);
                                               d2=d2;
                                                break
                                            end
                            end  
                            
                   
                            