function varargout = Pond_ChannelsDesign3(varargin)
%axes(handles.averSpec); % Make averSpec the current axes.
clc
clear global
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Pond_ChannelsDesign3_OpeningFcn, ...
                   'gui_OutputFcn',  [], ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);               
if nargin & isstr(varargin{1})    
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    %gui_mainfcn(gui_State, varargin{:});
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

 %feval(gui_State.gui_OutputFcn, gui_hFigure, [], gui_Handles);

% --- Executes just before Pond_ChannelsDesign3 is made visible.
function Pond_ChannelsDesign3_OpeningFcn(hObject, eventdata, handles, varargin)
%cla reset;

% Choose default command line output for Pond_ChannelsDesign3
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in compute.
function compute_Callback(hObject, eventdata, handles)
%cla reset;
% hObject    handle to compute (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

filename = 'testdata1.xls';
sheet = 1;
[ndata, text, A] = xlsread(filename);
%disp ('The data read from the excel spreadsheet is:')
%disp(A);

%A = xlsread('testdata1.xls');
cha = (get(handles.cha,'String'));
NU = str2double(get(handles.nu,'String'));
Q = str2double(get(handles.q,'String'));
STA = eval(get(handles.sta,'String'));
ELEV = eval(get(handles.elev,'String'));
yupst = str2double(get(handles.yu,'String'));
ydown = str2double(get(handles.yd,'String'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Constant_for_Y_SUB = 0.92;
Constant_for_Y_SUPER = 1.12;
tol = 0.000001;
num_itera = 500;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if cha=='c';
    cha='c';
else 
    cha='t';
end

j = 0;
for i= 4:4 + NU - 1;
    j = j+1;    
    L(j) = cell2mat(A(i,2)); %Reach length in m 
    s(j) = cell2mat(A(i,3)); %Bottom slope in m/m
    n(j) = cell2mat(A(i,5)); % Manning roughness
    
    if cha =='t'
        b(j) = cell2mat(A(i,4));
        zt(j) = cell2mat(A(i,6)); %Side slope
    else      
        d(j) = cell2mat(A(i,4)); %diameter
    end 
end 
waterprofilegeneralfinal;



