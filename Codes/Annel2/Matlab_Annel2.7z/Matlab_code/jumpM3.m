%Supercritical

 %Starting section of computation
                        yy = eval(['y',int2str(dd),'(rr-1);']);                         
                        mm = eval(['m',int2str(dd),'(rr-1);']); 
                        mm1 = mm + dx(dd);
                        zz = eval(['z',int2str(dd),'(rr-1);']);
                        zz1 = zz-s(e)*dx(dd);
                        
                        eval(['m',int2str(dd),'(rr)','= mm1;']);
                        eval(['z',int2str(dd),'(rr)','= zz1;']);
                            for i =1:num_itera;
                                if cha == 'c';
                                    te = 2*acos(1-2*yy/d(e));    
                                    A = 1/8*(te-sin(te))*d(e)^2;
                                    pe = 0.5*te*d(e);
                                    T = sin(te/2)*d(e); 
                                else 
                                    A = (b(e)+zt(e)*yy)*yy;
                                    pe = b(e)+2*yy*(1+(zt(e))^2)^(1/2);
                                    T = b(e)+2*zt(e)*yy;
                                end                                
                                R = A/pe;                            
                                v2 = (Q/A)^2/(2*9.8);
                                ar= 1/n(e)*A^(5/3)/pe^(2/3);
                                E22 = zz1+yy*ss(e)+v2;
                                sf22=(Q/ar).^2;
                                f = E22-E11+(sf11*sf22)^0.5*dx(dd); %Geometric mean friction slope
                            
                                if cha == 'c';
                                    df = 1-Q^2/9.8*T/A^3+dx(dd)/2*sf11^0.5*sf22^-0.5*Q^2*n(e)^2*(-10/3*pe^(4/3)*A^(-13/3)*T+(8/3)*A^(-10/3)*pe^(1/3)*(1-(1-2*yy/d(e))^2)^(-1/2));
                                  
                                else 
                                    df = 1-Q^2/9.8*T/A^3+dx(dd)/2*sf11^0.5*sf22^-0.5*Q^2*n(e)^2*(-10/3*pe^(4/3)*A^(-13/3)*T+(4/3)*A^(-10/3)*pe^(1/3)*(2*(1+(zt(e))^2)^0.5));
                                end 
                                yy= yy-f/df;
                                if (abs(f/df)/(yy - 0.5*f/df)<tol);
                                    eval(['y',int2str(dd),'(rr)','= yy;']); 
                                    d1 = yy;                            
                                    sf11=sf22;
                                    E11=E22;
                                    break
                                end
                            end
                            