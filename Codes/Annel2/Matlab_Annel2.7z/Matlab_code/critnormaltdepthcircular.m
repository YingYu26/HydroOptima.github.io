%critnormaltdepthcircular
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Critical and Normal depth 
 for j = 1:NU; %critical depth computation            
                    yc(j) = 0.10*d(j);
                        for i = 1:num_itera;
                                te = 2*acos(1-2*yc(j)/d(j));
                                A = 1/8*(te-sin(te))*d(j)^2; 
                                pe = 0.5*te*d(j);
                                T = sin(te/2)*d(j); 
                                f = 1-Q^2*T/(9.8*A^3);
                                df = -Q^2/9.8*(-3*T^2*A^-4+A^-3*(d(j)-2*yc(j))*(yc(j)*(d(j)-yc(j)))^(-1/2));
                                yc(j)= yc(j)-f/df;
                                if (abs(f/df)/(yc(j) - 0.5*f/df)<tol & yc(j) < Constant_for_Y_SUB*d(j));
                                    break
                                end
                                if (i > num_itera-2);
                                    yc(j) = 0.0;
                                    break
                                end
                                        
                        end
                    if s(j)>10^-10; %Normal depth computation
                        yn(j) = 0.3*d(j);
                        for k = 1:num_itera;
                                te = 2*acos(1-2*yn(j)/d(j));
                                A = 1/8*(te-sin(te))*d(j).^2; 
                                pe = 0.5*te*d(j);
                                T = sin(te/2)*d(j); 
                                f = Q-1/n(j)*A^(5/3)/pe^(2/3)*s(j)^0.5;
                                df = -s(j)^0.5/n(j)*(-4/3*A^(5/3)*pe^(-5/3)*(1-(1-2*yn(j)/d(j))^2)^(-1/2)+5/3*A^(2/3)*pe^-(2/3)*T);
                                yn(j)= yn(j)-f/df;
                                if (abs(f/df)/(yn(j) - 0.5*f/df)<tol & yn(j) < Constant_for_Y_SUB*d(j));
                                    F(j) = (Q/A)/(9.8*A/T)^0.5;
                                    break
                                end
                                if (k > num_itera-2);
                                    yn(j) = 1000000000;
                                    F(j) = 0;   
                                    break
                                end
                        end
                    else 
                        yn(j) = 1000000000;
                        F(j) = 0;                        
                    end
        end 
        
           
                    
                    