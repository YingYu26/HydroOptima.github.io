%Subcritical
%initial

                    yy =yd(e);
                    zz = eval(['z',int2str(e),'(1);']); 
                    zz1 = zz-s(e)*L(e);
                    mm = eval(['m',int2str(e),'(1);']); 
                    mm1 = mm+L(e);
                    eval(['y',int2str(e),'(p(e)+1)','= yy;']); 
                    eval(['m',int2str(e),'(p(e)+1)','= mm1;']); 
                    eval(['z',int2str(e),'(p(e)+1)','= zz1;']); 
                    te = 2*acos(1-2*yy/d(e));
                    A = 1/8*(te-sin(te))*d(e)^2;
                    pe = 0.5*te*d(e);
                    v2 = (Q/A)^2/(2*9.8);
                    ar= 1/n(e)*A^(5/3)/pe^(2/3);
                    E2 = zz1+yy*ss(e)+v2;
                    sf2=(Q/ar).^2;
                    %Streamwise
                    h = 2;
                    while h <= p(e)+1;
                    yy1 = eval(['y',int2str(e),'(p(e)+3-h);']);   
                    mm2 = mm+(p(e)+1-h)*dx(e);
                    zz2 = zz-s(e)*(mm2-mm);
                    eval(['m',int2str(e),'(p(e)+2-h)','= mm2;']); 
                    eval(['z',int2str(e),'(p(e)+2-h)','= zz2;']); 
                            for i = 1:num_itera;
                            te = 2*acos(1-2*yy1/d(e));    
                            A = 1/8*(te-sin(te))*d(e)^2;
                            pe = 0.5*te*d(e);
                            R = A/pe;
                            T = sin(te/2)*d(e);
                            v2 = (Q/A)^2/(2*9.8);
                            ar= 1/n(e)*A^(5/3)/pe^(2/3);
                            E1 = zz2+yy1*ss(e)+v2;
                            sf1=(Q/ar).^2;                            
                            f = E2-E1+0.5*(sf1+sf2)*dx(e); %Aritmetic mean friction slope
                            
                            df = -(1-Q^2/9.8*T/A^3)+dx(e)/2*Q^2*n(e)^2*(-10/3*pe^(4/3)*A^(-13/3)*T+8/3*A^(-10/3)*pe^(1/3)*(1-(1-2*yy1/d(e))^2)^(-1/2));
                            yy1= yy1-f/df;       
                            
                                                            if ((i>num_itera-2) & (yy1>=Constant_for_Y_SUB*d(e)));
                                                                eval(['y',int2str(e),'(p(e)+2-h)','= d(e);']); 
                                                                yy1 = Constant_for_Y_SUB*d(e);
                                                                te = 2*acos(1-2*yy1/d(e));    
                                                                A = 1/8*(te-sin(te))*d(e)^2;
                                                                pe = 0.5*te*d(e);
                                                                R = A/pe;
                                                                v2 = (Q/A)^2/(2*9.8);
                                                                ar= 1/n(e)*A^(5/3)/pe^(2/3);
                                                                E1 = zz2+yy1*ss(e)+v2;
                                                                sf1=(Q/ar).^2;
                                                                break                                                                
                                                            end 
                                                            
                                                            if (abs(f/df)/(yy1 - 0.5*f/df)<tol);
                                                                eval(['y',int2str(e),'(p(e)+2-h)','= yy1;']); 
                                                                break
                                                            end
                            end
                    sf2=sf1;
                    E2=E1;
                    h=h+1;
                    end                    
                    yy5 = eval(['y',int2str(e),'(1);']);                    
                    te = 2*acos(1-2*yy5/d(e));    
                    A = 1/8*(te-sin(te))*d(e)^2;
                    v2 = (Q/A)^2/(2*9.8);
                    zz5 = eval(['z',int2str(e),'(1);']); 
                    EE5 = yy5*ss(e)+v2+zz5;
                    eval(['EN',int2str(e),'(1)','= EE5;']);                    
                    
                    yy6 = eval(['y',int2str(e),'(p(e)+1);']);                    
                    te = 2*acos(1-2*yy6/d(e));    
                    A = 1/8*(te-sin(te))*d(e)^2;
                    v2 = (Q/A)^2/(2*9.8);
                    zz6 = eval(['z',int2str(e),'(p(e)+1);']); 
                    EE6 = yy6*ss(e)+v2+zz6;
                    eval(['EN',int2str(e),'(2)','= EE6;']); 