%critnormaltdepthtrapezoidal
%Critical and Normal depth 
 for j = 1:NU;%critical depth computation
                    yc(j) = Q/200;
                        for i = 1:num_itera;
                                A = (b(j)+zt(j)*yc(j))*yc(j); 
                                T = b(j)+2*zt(j)*yc(j);
                                f = 1-Q^2*T/(9.8*A^3);
                                df = -Q^2/9.8*(-3*T^2*A^-4+A^(-3)*2*zt(j));
                                yc(j)= yc(j)-f/df;
                                if (abs(f/df)/(yc(j) + 0.5*f/df)<tol);
                                    break
                                end
                                if (i > num_itera-2);
                                    yc(j) = 0.0;
                                    break
                                end 
                        end            
                if s(j)>0; %Normal depth computation
                    yn(j) = Q/20;
                        for k = 1:num_itera;
                                A = (b(j)+zt(j)*yn(j))*yn(j);
                                pe = b(j)+2*yn(j)*(1+zt(j)^2)^(1/2);
                                R = A/pe;
                                T = b(j)+2*zt(j)*yn(j);
                                f = Q-1/n(j)*A*R^(2/3)*s(j)^0.5;
                                df = -s(j)^0.5/n(j)*(-4/3*R^(5/3)*(1+zt(j)^2)^0.5+5/3*R^(2/3)*T);
                                yn(j)= yn(j)-f/df;
                                if (abs(f/df)/(yn(j) - 0.5*f/df)<tol);
                                    F(j) = (Q/A)/(9.8*A/T)^0.5;
                                	break
                                end
                                if (k > num_itera-2);
                                    yn(j) = 1000000000;
                                    F(j) = 0;
                                end 
                        end
                else
                    yn(j) = 1000000000;
                    F(j) = 0;
                end     
        end   
        
        
        