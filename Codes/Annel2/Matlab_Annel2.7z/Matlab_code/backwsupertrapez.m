%Supercritical
 %initial
                    yy = eval(['y',int2str(e),'(1);']);
                    zz = eval(['z',int2str(e),'(1);']); 
                    A = (b(e)+zt(e)*yy)*yy;
                    pe = b(e)+2*yy*(1+zt(e)^2)^(1/2);
                    v2 = (Q/A)^2/(2*9.8);
                    ar= 1/n(e)*A^(5/3)/pe^(2/3);
                    E1 = zz+yy*ss(e)+v2;
                    sf1=(Q/ar).^2;
                    %Streamwise
                    h = 2; 
                    while h <= p(e)+1;
                        yy = eval(['y',int2str(e),'(h-1);']);                         
                        mm = eval(['m',int2str(e),'(1);']); 
                        mm1 = mm + (h-1)*dx(e);
                        zz1 = zz-s(e)*(mm1-mm);
                        eval(['m',int2str(e),'(h)','= mm1;']);
                        eval(['z',int2str(e),'(h)','= zz1;']);
                            for i =1:num_itera;
                            A = (b(e)+zt(e)*yy)*yy;
                            pe = b(e)+2*yy*(1+zt(e)^2)^(1/2);
                            R = A/pe;
                            T = b(e)+2*zt(e)*yy;
                            v2 = (Q/A)^2/(2*9.8);
                            ar= 1/n(e)*A^(5/3)/pe^(2/3);
                            E2 = zz1+yy*ss(e)+v2;
                            sf2=(Q/ar).^2;
                            f = E2-E1+(sf1*sf2)^0.5*dx(e); %Geometric mean friction slope
                            df = 1-Q^2/9.8*T/A^3+dx(e)/2*sf1^0.5*sf2^(-0.5)*Q^2*n(e)^2*(-10/3*pe^(4/3)*A^(-13/3)*T+(4/3)*A^(-10/3)*pe^(1/3)*(2*(1+zt(e)^2)^0.5));
                            yy= yy-f/df;
                            
                                            if (abs(f/df)/(yy - 0.5*f/df)<tol);                                           
                                                eval(['y',int2str(e),'(h)','= yy;']); 
                                                break
                                            end
                            end
                        sf1=sf2;
                        E1=E2;
                        h=h+1;
                    end
                    yy5 = eval(['y',int2str(e),'(1);']);
                    A = (b(e)+zt(e)*yy5)*yy5;
                    v2 = (Q/A)^2/(2*9.8);
                    zz5 = eval(['z',int2str(e),'(1);']); 
                    EE5 = yy5*ss(e)+v2+zz5;
                    eval(['EN',int2str(e),'(1)','= EE5;']);
                    
                    yy6 = eval(['y',int2str(e),'(p(e)+1);']); 
                    A = (b(e)+zt(e)*yy6)*yy6;
                    v2 = (Q/A)^2/(2*9.8);
                    zz6 = eval(['z',int2str(e),'(p(e)+1);']); 
                    EE6 = yy6*ss(e)+v2+zz6;
                    eval(['EN',int2str(e),'(2)','= EE6;']);  
                                                                                
                    
                         